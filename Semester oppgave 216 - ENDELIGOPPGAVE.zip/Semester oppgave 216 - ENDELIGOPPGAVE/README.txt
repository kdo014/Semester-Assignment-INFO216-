THIS TEXT FILE IS MEANT TO HELP THE READER RUN THE CODE PROPERLY.
------------------------------------------------------------------

To start using the code provided, follow these steps:

    If you have not already downloaded Java SDK download it Java SE Development kit.

    Go to 'file' in the top navigational bar, select 'project structure'.
    You will find the Project SDK settings. Select any SDK after version 7


    If you have not already downloaded Apache Jena visit Apache Jena's website and download the jar file.

    Go to 'file' in the top navigational bar, select 'project structure'.
    You will find a category called 'Libraries'. Select this and click on the '+' sign down left in this module.
    Navigate to the place you've downloaded the Jena folder and enter this folder.
    Enter the folder that says 'lib' and select this folder to add it to the project structure library.

------------------------------------------------------------------
After completing the project structure steps, run the class called 'Main'. This will run our program in an interface.

If you do not select anything and then press 'Search' after opening the interface, every movie will be returned with their movie title.
